class Error(Exception):
    pass
