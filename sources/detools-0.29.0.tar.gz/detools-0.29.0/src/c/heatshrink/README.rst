The files in this folder are copied from the heatshrink project,
https://github.com/atomicobject/heatshrink.

Licensed under the ISC License.
